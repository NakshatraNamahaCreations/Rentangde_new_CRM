export const ApiURL = "https://api.rentangadi.in/api";
export const ImageApiURL = "https://api.rentangadi.in";

// export const ApiURL = "http://192.168.1.199:8000/api";
// export const ImageApiURL = "http://192.168.1.199:8000";
